Please note that a game controller is required.
The game was developed and tested with a generic PS4 style controller for windows.